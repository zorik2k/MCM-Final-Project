//
//  MuseumData.h
//  MCM-Final Project
//
//  Created by Zorik on 4/30/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Museum.h"

@interface MuseumInfo : NSObject {
    
    Museum *museum;    
   
    
    
}
@property (nonatomic,retain) Museum *museum;



@end
