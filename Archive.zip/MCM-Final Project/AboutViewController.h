//
//  aboutViewController.h
//  MCM-Final Project
//
//  Created by Zorik on 5/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface AboutViewController : UIViewController {
    UINavigationController *navigationController;

    
    
}
@property (nonatomic,retain)     UINavigationController *navigationController;


@end
