//
//  Helper.h
//  TestingStuff
//
//  Created by Zorik on 5/14/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Helper : NSObject {
    
}

@end
