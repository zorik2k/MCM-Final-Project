//
//  TestingStuffTests.m
//  TestingStuffTests
//
//  Created by Zorik on 5/14/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "TestingStuffTests.h"


@implementation TestingStuffTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in TestingStuffTests");
}

@end
