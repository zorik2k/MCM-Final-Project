//
//  MCM_Final_ProjectTests.h
//  MCM-Final ProjectTests
//
//  Created by Zorik on 4/30/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface MCM_Final_ProjectTests : SenTestCase {
@private
    
}

@end
