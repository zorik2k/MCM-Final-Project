//
//  MCM_Final_ProjectTests.m
//  MCM-Final ProjectTests
//
//  Created by Zorik on 4/30/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MCM_Final_ProjectTests.h"


@implementation MCM_Final_ProjectTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in MCM-Final ProjectTests");
}

@end
